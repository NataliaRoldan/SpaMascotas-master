﻿namespace SpaMascotas
{
    partial class FormReporte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtpropietario = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtMascota = new System.Windows.Forms.Label();
            this.txtEstrato = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.Label();
            this.txtIdentificacion = new System.Windows.Forms.Label();
            this.txtServicio = new System.Windows.Forms.Label();
            this.txtDescuento = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(41, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 15);
            this.label1.TabIndex = 21;
            this.label1.Text = "Nombre del propietario";
            // 
            // txtpropietario
            // 
            this.txtpropietario.AutoSize = true;
            this.txtpropietario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtpropietario.Location = new System.Drawing.Point(214, 72);
            this.txtpropietario.Name = "txtpropietario";
            this.txtpropietario.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtpropietario.Size = new System.Drawing.Size(20, 15);
            this.txtpropietario.TabIndex = 22;
            this.txtpropietario.Text = "na";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(41, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 15);
            this.label2.TabIndex = 23;
            this.label2.Text = "Nombre Mascota";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(41, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 15);
            this.label3.TabIndex = 24;
            this.label3.Text = "Estrato";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(41, 267);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 15);
            this.label4.TabIndex = 25;
            this.label4.Text = "Total";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(407, 72);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 15);
            this.label9.TabIndex = 26;
            this.label9.Text = "Identificacion";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(407, 140);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 15);
            this.label10.TabIndex = 27;
            this.label10.Text = "Servicio";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(407, 203);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 15);
            this.label11.TabIndex = 28;
            this.label11.Text = "Descuento";
            // 
            // txtMascota
            // 
            this.txtMascota.AutoSize = true;
            this.txtMascota.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtMascota.Location = new System.Drawing.Point(214, 140);
            this.txtMascota.Name = "txtMascota";
            this.txtMascota.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtMascota.Size = new System.Drawing.Size(20, 15);
            this.txtMascota.TabIndex = 29;
            this.txtMascota.Text = "na";
            // 
            // txtEstrato
            // 
            this.txtEstrato.AutoSize = true;
            this.txtEstrato.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtEstrato.Location = new System.Drawing.Point(214, 212);
            this.txtEstrato.Name = "txtEstrato";
            this.txtEstrato.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtEstrato.Size = new System.Drawing.Size(20, 15);
            this.txtEstrato.TabIndex = 30;
            this.txtEstrato.Text = "na";
            // 
            // txtTotal
            // 
            this.txtTotal.AutoSize = true;
            this.txtTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtTotal.Location = new System.Drawing.Point(214, 267);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtTotal.Size = new System.Drawing.Size(20, 15);
            this.txtTotal.TabIndex = 31;
            this.txtTotal.Text = "na";
            // 
            // txtIdentificacion
            // 
            this.txtIdentificacion.AutoSize = true;
            this.txtIdentificacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtIdentificacion.Location = new System.Drawing.Point(584, 72);
            this.txtIdentificacion.Name = "txtIdentificacion";
            this.txtIdentificacion.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtIdentificacion.Size = new System.Drawing.Size(20, 15);
            this.txtIdentificacion.TabIndex = 32;
            this.txtIdentificacion.Text = "na";
            // 
            // txtServicio
            // 
            this.txtServicio.AutoSize = true;
            this.txtServicio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtServicio.Location = new System.Drawing.Point(584, 140);
            this.txtServicio.Name = "txtServicio";
            this.txtServicio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtServicio.Size = new System.Drawing.Size(20, 15);
            this.txtServicio.TabIndex = 33;
            this.txtServicio.Text = "na";
            // 
            // txtDescuento
            // 
            this.txtDescuento.AutoSize = true;
            this.txtDescuento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtDescuento.Location = new System.Drawing.Point(584, 203);
            this.txtDescuento.Name = "txtDescuento";
            this.txtDescuento.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtDescuento.Size = new System.Drawing.Size(20, 15);
            this.txtDescuento.TabIndex = 34;
            this.txtDescuento.Text = "na";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(449, 268);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 35;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormReporte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtDescuento);
            this.Controls.Add(this.txtServicio);
            this.Controls.Add(this.txtIdentificacion);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtEstrato);
            this.Controls.Add(this.txtMascota);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtpropietario);
            this.Controls.Add(this.label1);
            this.Name = "FormReporte";
            this.Text = "FormReporte";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label label1;
        public Label txtpropietario;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label9;
        private Label label10;
        private Label label11;
        public Label txtMascota;
        public Label txtEstrato;
        public Label txtTotal;
        public Label txtIdentificacion;
        public Label txtServicio;
        public Label txtDescuento;
        private Button button1;
    }
}